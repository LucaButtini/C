#include<stdio.h>
void main() {
   int add=5 ,add2=3, somma;
   somma=add+add2;

   printf("la somma è: %d",somma);
}