#include <stdio.h>
void main() {
    printf("Hello world!"); //scrive a video
}