//programma che calcola la somma di due numeri
#include<stdio.h>
void main() {
   int contatore,add=5 ,add2=3, somma; //quando le creo sto inizializzando la variabile
   float add3,add4,somma2;
   somma=add+add2;

   printf("la somma tra numeri interi è: %d \n",somma); //scrittura a video
   add3=2.5;
   add4=3.75;//assegno un valore alla variabile = assegnazione
   somma2=add3+add4;
   printf("la somma tra numeri reali è: %f \n",somma2); //scrittura a video
   contatore=contatore+1; //se non le do un valore il computer da una cifra a caso, molte delle volte zero.
   printf("la variabile contatore vale: %d\n", contatore); //scrittura a video
   contatore++;//qui è in forma sintetica in base a quanti operatori scrivi
    printf("la variabile contatore vale: %d\n", contatore); //scrittura a video
   contatore--;
 printf("la variabile contatore vale: %d\n", contatore); //scrittura a video
}
